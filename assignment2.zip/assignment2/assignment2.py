import os
import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, precision_recall_fscore_support
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC, LinearSVC
import matplotlib.pyplot as plt

dir_path = "2Newsgroups"
# Load vocabulary
with open(os.path.join(dir_path, 'modifiedterms.txt'), 'r') as file:
    vocabulary = file.read().splitlines()
vocabulary.pop() #remove last empty string

# Loading the training data
X_train_data = np.loadtxt(os.path.join(dir_path, 'trainMatrixModified.txt')).T
y_train_data = np.loadtxt(os.path.join(dir_path, 'trainClasses.txt'), dtype=int)[:, 1]

# Loading the test data
X_test_data = np.loadtxt(os.path.join(dir_path, 'testMatrixModified.txt')).T
y_test_data = np.loadtxt(os.path.join(dir_path, 'testClasses.txt'), dtype=int)[:, 1]

# Creating the TfidfTransformer with the TF matrix
vectorizer = TfidfTransformer()

# Fit and transform the training data
X_train_tfidf = vectorizer.fit_transform(X_train_data)

# Transform the test data
X_test_tfidf = vectorizer.transform(X_test_data)

# Implementing KNN Classifier using cosine
knn_model = KNeighborsClassifier(n_neighbors=4, metric='cosine')  # Set the number of neighbors
knn_model.fit(X_train_tfidf, y_train_data)
knn_predictions = knn_model.predict(X_test_tfidf)

# Implementing LinearSVM Classifier
svm_model = LinearSVC(dual=True)
svm_model.fit(X_train_data, y_train_data)
svm_predictions = svm_model.predict(X_test_data)


# Implementing the Multinomial Naive Bayes Classifier
class MultinomialNaiveBayes:
    def __init__(self):
        self.vocabulary = None
        self.priors = None
        self.cond_probs = None
        self.num_classes = None

    def fit(self, X_train, y_train, vocabulary):
        self.vocabulary = vocabulary
        self.num_classes = len(np.unique(y_train))
        self.priors = np.zeros(self.num_classes)
        self.cond_probs = np.zeros((len(vocabulary), self.num_classes))

        # Iterate over all possible classes
        for c in range(self.num_classes):
            X_c = X_train[y_train == c]
            num_documents_in_c = X_c.shape[0]
            self.priors[c] = num_documents_in_c / X_train.shape[0]  # Adjusting to use X_train.shape[0]

            total_word_count = np.sum(X_c)
            for i, word_count in enumerate(np.sum(X_c, axis=0)):
                self.cond_probs[i][c] = (word_count + 1) / (total_word_count + len(vocabulary))
            

    def predict(self, X_test):
        predictions = []
        for document in X_test:
            scores = [np.log(prior) for prior in self.priors]
            for word_index, word_count in enumerate(document):
                if word_count == 0:
                    continue
                for c in range(len(scores)):
                    scores[c] += word_count * np.log(self.cond_probs[word_index][c])
            predicted_class = np.argmax(scores)
            predictions.append(predicted_class)
        return np.array(predictions)
    
# Instantiate and fit the MNB classifier
mnb_model = MultinomialNaiveBayes()
mnb_model.fit(X_train_data, y_train_data, vocabulary)
mnb_predictions = mnb_model.predict(X_test_data)


# Classifiers Evaluation
classifiers = {
    "K-Nearest Neighbors": knn_predictions,
    "Support Vector Machine": svm_predictions,
    "Multinomial Naive Bayes": mnb_predictions
}

# Output filenames
filenames = {
    "K-Nearest Neighbors":"KNN",
    "Support Vector Machine": "SVM",
    "Multinomial Naive Bayes": "NB"
}


def plot_confusion_matrix(y_pred, y_true, classifier_name):
    confusion_mat = confusion_matrix(y_pred, y_true, labels=[0, 1])
    plt.figure(figsize=(6, 4))
    plt.imshow(confusion_mat, interpolation='nearest')
    plt.colorbar()
    plt.title(f"{classifier_name} Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.xticks([0, 1], ['0', '1'])
    plt.yticks([0, 1], ['0', '1'])
    for (x, y), value in np.ndenumerate(confusion_mat):
        plt.text(x, y, value, va="center", ha="center")
    plt.savefig(f"{filenames[classifier_name]}_CM.jpg", bbox_inches='tight', dpi=300)
    plt.close()

# Plot Confusion Matrices images - Output
for clf_name, y_pred in classifiers.items():
    plot_confusion_matrix(y_pred, y_test_data, clf_name)

def plot_evaluation_metrics(y_pred, y_test, classifier_name):
    # if classifier_name == 'Multinomial Naive Bayes':
    #     print(classifier_name)
    #     accuracy = accuracy_score(y_test, y_pred)
    #     precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_test, average='binary')
    # else:
    accuracy = accuracy_score(y_test, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_pred, y_test, average='binary')
      
    x = ['Precision', 'Recall', 'F-Score', 'Accuracy']
    y = [round(i, 3) for i in [precision, recall, f1, accuracy]]
    fig, ax = plt.subplots(figsize=(8, 5))

    ax.plot(x, y, linestyle='-')
    ax.margins(y=3.0)
    ax.set_ylim([None, 1])
    ax.set_title(f"{classifier_name} Evaluation Metrics")
    plt.savefig(f"{filenames[classifier_name]}_EM.jpg", bbox_inches='tight', dpi=300)
    plt.close()

# Plot evaluation metrics images - Output
for clf_name, y_pred in classifiers.items():
    plot_evaluation_metrics(y_pred, y_test_data, clf_name)

# Create text files - Output
for clf_name, y_pred in classifiers.items():
    accuracy = accuracy_score(y_test_data, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_pred, y_test_data, average='binary')
    confusion_mat = confusion_matrix(y_test_data, y_pred, labels=[0, 1])
    # print(np.array2string(confusion_mat))
    confusion_mat = str(confusion_mat).replace('[', '').replace(']', '').replace('\n ', '\n')
#    confusion_mat = str(confusion_mat).replace('[', '').replace(']', '').replace('\n ', '\n')
    # print(confusion_mat)
   

    with open(f"{filenames[clf_name]}.txt", "w") as file:
        file.write(f"Accuracy:{accuracy}\n")
        file.write(f"Precision:{precision}\n")
        file.write(f"Recall:{recall}\n")
        file.write(f"F1:{f1}\n")
        file.write("Confusion Matrix:\n")
        file.write((confusion_mat))
