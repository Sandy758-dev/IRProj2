Wright State University
Department of Computer Science and Engineering
CS7800 Information Retrieval 
Spring 2024
Assignment -2

Team Members’ Names and Details:
Name: Jesly P Johnson
UID: U01093321
Email: johnson.2123@wright.edu 

Name : Sandhya Bodige
UID : U01100050
Email: bodige.4@wright.edu 


Overview:  To implement various classifiers both manually and using scikit-learn APIs in Python. The project comprises two phases. During Phase I, we need to construct classifiers and apply them to the modified 2 Newsgroup dataset. In Phase II, we need to evaluate these classifiers using metrics such as accuracy and confusion matrix to determine their classification quality.

Application Launch:
1. Download the  2Newsgroups folder and unzip it
2. Right click on the unzipped folder and select to open this folder on terminal 
4. Download VSCode and use it for coding
3. To Launch the application run the following commands in the terminal.

Python version -3.11.5 
Mac OS
	python3 -m venv .venv or python -m venv .venv
	source .venv/bin/activate
	pip install scikit-learn
	pip install matplotlib
Run the following to execute the output
	python3 assignment2.py (or python assignment2.py)

Windows OS
	python3 -m venv .venv or python -m venv .venv
	cmd
	source .venv\Scripts\activate
	pip install scikit-learn
	if prompted to upgrade your pip3 , upgarde accordingly
	pip install matplotlib
Run the following to execute the output
	python assignment2.py


External libraries : import os
import numpy as np
from sklearn.metrics import confusion_matrix, accuracy_score, precision_recall_fscore_support
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC, LinearSVC
import matplotlib.pyplot as plt   The dataset is a subset of the 20 newsgroup corpus http://qwone.com/~jason/20Newsgroups/  in term-document format. This subset has been taken from http://mlg.ucd.ie/content/view/22/ (this data was modified to remove terms that did not appear in any of the documents). Each document belong to one of the two classes {Windows, Hockey}. The original data has been divided into test and train (20%, 80%) subsets.

The files contained in the archive file are as follows:

1. trainMatrixModified.txt: the term-document frequency matrix for the training documents. Each row of this matrix corresponds to one of the terms and each column corresponds to one of the documents and the (i,j)th element of the matrix shows the frequency of the ith term in the jth document. This matrix contains 5500 rows and 800 columns.

2. testMatrixModified.txt: the term-document frequency for the test documents. The matrix contains 5500 rows and 200 columns.

3. trainClasses.txt: This file contains the labels associated with each training document. Each line is in the format of documentIndex \t classId where the documentIndex is in the range of [0,800) and refers to the index of the document in the term-document frequency matrix for train documents. The classId refers to one of the two classes and takes one of the values 0 (for Windows) or 1 (for Hockey).

4. testClasses.txt: This file contains the labels associated with each test document. Each line is in the format of documentIndex \t classId where the documentIndex is in the range of [0,200) and refers to the index of the document in the term-document frequency matrix for test documents.  

5. modifiedterms.txt: This file contains the set of 5500 terms in the vocabulary. Each line contains a term and corresponds to the corresponding rows in term-document frequency matrices. 

